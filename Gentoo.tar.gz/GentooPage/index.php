<?php
define('INCLUDE_CHECK',1);
require "connect.php";
session_start();
?>
<!-- ====================================================================================================================================================-->
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link title="new" rel="stylesheet" href="CSS/gentoo.css" type="text/css">    
<link type="text/css" rel="stylesheet" href="CSS/panel.css"/>
<link rel="stylesheet" type="text/css" href="CSS/shopping.css"/>
<link type="text/css" rel="stylesheet" href="CSS/login.css"/>
<link type="text/css" rel="stylesheet" href="CSS/alpha.css"/>
<link type="text/css" rel="stylesheet" href="CSS/tabs.css"/>
<link href="front.css" media="screen, projection" rel="stylesheet" type="text/css">
<link href="img/icon_page.gif" rel="icon" /> 

<script type="text/javascript" src="Jquery/jquery.min.js"></script>
<script type="text/javascript" src="Jquery/tabs.js"></script>
<script type="text/javascript" src="Jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="Jquery/jquery.simpletip-1.3.1.pack.js"></script>
<script type="text/javascript" src="javaScript/script.js"></script>
<script type="text/javascript" src="javaScript/validar_producto.js"></script>
<script type="text/javascript" src="Jquery/login-jquery.js"></script> 
<script type="text/javascript"> 
$(document).ready(function(){
    $("#login-link").click(function(){
        $("#login-panel").slideToggle(200);
    })
})
$(document).keydown(function(e) {
    if (e.keyCode == 27) {
        $("#login-panel").hide(0);
    }
});
</script> 
<title>w4rl0ck - Home</title>
</head>

<body style="margin:0px 15px 5px 15px;">
<!-- ===================== LOGIN ======================================= LOGIN ================================= LOGIN ========================================-->

<div id="demo-header">

<?php
require("menu.php");
if (isset($_SESSION['username'])) {?>
    <b><a id="login-link" href="logout.php" title="Logout"><span style="color: cyan;"><?php echo $_SESSION['username'];?></span> | Logout</a></b>
<?php }else{require("twitter.html");} ?>

<!-- =======================================================================================================================================================-->

<div class="news">
<td style="valign:top;margin-top:10px;  background: url(img/phones2.jpg) repeat-y;background-attachment: fixed;">
<div class="news" style="background-color: transparent;">
<div id="column-1" class="container">
<div class="overlay" style="margin-top:7px"></div>
<div style="position:relative; padding-left:17px;margin:15px">

<?php
if (isset($_GET['id'])){ // muestra un producto seleccionado por el usuario
    require("ver_producto.php");
}
else{                   // muestra los productos de una categoria
     if (isset($_GET['categoria'])){
    $result = mysql_query("select i.id, img, name from internet_shop i join `categ-product` cp on cp.id_producto = i.id where cp.id_categoria=".$_GET['categoria']);}
    else{               // muestra todos los productos
         $result = mysql_query("SELECT id, img ,name  FROM internet_shop");}
  while($row=mysql_fetch_assoc($result))
     {
    ?>
                <div id="product" style="margin-bottom: 10px;text-align:center; padding:10px">
                   <img src="img/img/products/<?php echo $row['img']?>" alt="<?php echo htmlspecialchars($row['name']) ?>" width="110" height="110" class="pngfix" />
                    <br>
                    <a href="index.php?id=<?php echo $row['id']; ?>">Add</a>
                    <br>
                    <p style="color:#FFFFFF"> <?php echo $row['name'] ;?></p>
                </div>
 <?php } } ?>
                </div>
</div>
</div>
</div>
</div>

<?php require "ofertas.php";?>
