<?php session_start();
session_destroy();
?>
<SCRIPT LANGUAGE="javascript">
location.href = "index.php";
</SCRIPT>
