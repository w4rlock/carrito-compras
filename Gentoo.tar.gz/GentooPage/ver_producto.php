<div style="position:relative; padding: 0px 30px 20px 0px; margin: 0px">
     <table style="width: 100%; border-collapse: collapse;"> 
     <tr>
<?php
define('INCLUDE_CHECK',1);
require "connect.php";session_start();
if ($_POST['precio']){
$query= "update internet_shop set description='".$_POST['descripcion']."'";
$query .= ", price=".$_POST['precio'].", modelo='".$_POST['modelo']."', stock=".$_POST['stock'];
$query .= " where id=".$_POST['id'];
mysql_query($query) or die(mysql_error());
header("location:index.php?id=".$_POST['id']);
echo "correcto";
}
if ($_GET['id']){
$id=$_GET['id'];}
else{
$id=$_POST['id'];
}
$result = mysql_query("select id, img, i.name as ProdName, description, price, idmanufactura,modelo,stock, m.name as ManufactName from internet_shop i join manufactura m on i.id_manufactura = m.idmanufactura where i.id=".$id);
$row=mysql_fetch_assoc($result);
if($_SESSION['root']){?>
<div style="position:relative; padding: 0px 30px 20px 0px; margin: 0px">
     <table style="width: 100%; border-collapse: collapse;"> 
     <tr> 
        <div style="color:#FFFFFF;"><h3> <?php echo $row['ProdName'] ;?></h3></div>
        <td style="text-align: center; width: 220px; vertical-align: top;"> 
        <img src="img/img/products/<?php echo $row['img']?>" alt="<?php echo htmlspecialchars($row['ProdName']) ?>" width="210" height="210" class="pngfix" />
        <br/>
        <span style="font-size: 11px;color:#FFFFFF;">Click para Cambiar</span></td> 
 
        <td style="padding-left: 10px; width: 296px; vertical-align: top;">
        <br>
        <form action="ver_producto.php" name="frm1" onsubmit="return validar(this);"  method="post">
        <table width="99%" cellspacing="10" style="color:#FFFFFF; margin-left:0px;"> 
        <tr> 
        <td><b>Precio:</b></td> 
        <td><input id="edit" type="text" name="precio" onkeypress="return validarNum(event)" value="<?php echo $row['price'];?>"> </td> 
            <input id="edit" type="hidden" name="id" value="<?php echo $row['id'];?>">
        </tr> 
        <tr> 
        <td><b>Disponibilidad:</b></td> 
        <td><input type="text" name="promocion" value="<?php echo $row['price'];?>"></td> 
        </tr> 
        <tr> 
        <td><b>Modelo:</b></td> 
        <td><input type="text" name="modelo" value="<?php echo $row['modelo'];?>"> </td> 
        </tr> 
        <tr> 
        <td><b>Manufactura:</b></td> 
        <td>
        <select name="manufactura">
        <?php 
        $result=mysql_query("select * from manufactura");
        while($r=mysql_fetch_assoc($result)){
        if ($r['name']==$row['ManufactName']){
        ?>
            <option value="<?php echo $r['id']; ?>" SELECTED>
        <?php } else{?>
            <option value="<?php echo $r['id']; ?>">
        <?php } echo $r['name']; ?>
        </option>
        <?php }?>
        </a></td> 
        </tr> 
        <tr> 
        <td><b>Stock:</b></td> 
        <td><input type="text" name="stock"  onkeypress="return validarNum(event)" value="<?php echo $row['stock'];?>"></td> 
        </tr> <tr>
        <td/><td><input type="SUBMIT" style="width:70px; height:25px;" value="Actualizar"/></td></tr>
        </table> 

                    </td> 
                    </tr> 
                    </table>
                    <ul class="tabs">
                    <li><a href="#tab1">Descripcion</a></li>
                    <li><a href="#tab2">Imagenes</a></li>
                    </ul>
  <div class="tab_container">
          <div id="tab1" class="tab_content">
          <textarea rows="7" name="descripcion" cols="60"> <?php echo $row['description']?></textarea>
             </div> 
             <div id="tab2" class="tab_content">
          <?php 
               $result=mysql_query("select p.picture from internet_shop i join pictures p on i.id = p.id_Producto where i.id=".$_GET['id']);
               while($row=mysql_fetch_assoc($result)){
               ?>
          <img src="img/img/products/<?php echo $row['picture']?>" alt="" height="140" width="140" />
          <?php } ?>
   </div>
  </div> 
</form>
</div>
<?php } 
 else{ ?>
        <div style="color:#FFFFFF; float:left;"><h3> <?php echo $row['ProdName'] ;?></h3></div>
        <td style="text-align: center; width: 220px; vertical-align: top;"> 
        <img src="img/img/products/<?php echo $row['img']?>" alt="<?php echo htmlspecialchars($row['ProdName']) ?>" width="210" height="210" class="pngfix" />
        <br/>
        <span style="font-size: 11px;color:#FFFFFF;">Click para Agrandar</span></td> 
        <td style="padding-left: 15px; width: 296px; vertical-align: top;">
        <br>
        <table width="99%" style="color:#FFFFFF; margin-left:40px;"> 
        <tr> 
        <td><b>Precio:</b></td> 
        <td>$ <?php echo $row['price'];?> </td> 
        </tr> 
        <tr> 
        <td><b>Disponibilidad:</b></td> 
        <td>En Stock</td> 
        </tr> 
        <tr> 
        <td><b>Modelo:</b></td> 
        <td><?php echo $row['modelo']?></td> 
        </tr> 
        <tr> 
        <td><b>Manufactura:</b></td> 
        <td><a href=""><?php echo $row['ManufactName'];?></a></td> 
        </tr> 
        <tr> 
        <td><b>Vendidos:</b></td> 
        <td>     9            </td> 
        </tr> 
        </table> 
        <form action="" method="post" enctype="multipart/form-data"> 
              <div style="background: #FFFFCC;border: 1px solid #FFCC33;margin-left:40px; padding: 15px; margin-top: 20px; margin-bottom: 15px;"> 
              <table style="width: 100%; border-collapse: collapse;"> 
              <tr><td>
               Cant: <input type="text" name="cantidad" maxlength="3" size="3" value="1" /> 
                   <a href=""><img src="img/img/target-add.gif" style="padding-left:15px" width="120"/></a>
                    </td></tr>
                    </table> </div> 
                    <div> 
                          <input type="hidden" name="product_id" value="47" /> 
                          <input type="hidden" name="redirect" value="" />                
                    </div> 
                    </form> 
                    </td> 
                    </tr> 
                    </table>
                    <ul class="tabs">
                    <li><a href="#tab1">Descripcion</a></li>
                    <li><a href="#tab2">Imagenes</a></li>
                    </ul>
  <div class="tab_container">
          <div id="tab1" class="tab_content">
          
          <?php echo $row['description']?> 
             </div> 
             <div id="tab2" class="tab_content">
          <?php 
               $result=mysql_query("select p.picture from internet_shop i join pictures p on i.id = p.id_Producto where i.id=".$_GET['id']);
               while($row=mysql_fetch_assoc($result)){
               ?>
          <img src="img/img/products/<?php echo $row['picture']?>" alt="" height="140" width="140" />
          <?php } ?>
   </div>
  </div> 
</div>
<?php } ?>
