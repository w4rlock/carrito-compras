<td width="1%" bgcolor="#dddaec"  valign="top">
<div style="border: 2px solid #BE81F7; margin:15px 10px 5px 10px;background-color:#EFFBFB;padding:0px 0px 20px 0px;" >       
<div style="border: 2px solid #AC58FA; background-color:#AC58FA; color:#FFFFFF;text-align:center;"><h3>OFERTAS</h3></div>
<table cellpadding="2"  cellspacing="0" style="width: 100%;"> 
<?php

$result=mysql_query("select * from ofertas o join internet_shop i on o.id_producto = i.id");
while($row=mysql_fetch_assoc($result))
{
?>
<tr> 
   <td  style="padding:5px 0px 0px 10px">
        <img src="img/img/products/<?php echo $row['img']?>" alt="<?php echo htmlspecialchars($row['name']) ?>" width="40" height="40" class="pngfix" />
   </td>
   <td  style="padding:5px 10px 0px 10px">
        <a href="index.php?id=<?php echo $row['id']; ?>"><?php echo $row['name']?></a>
        <br /> 
        <span style="font-size: 11px; color: #900;">$ <?php echo $row['price']?></span> 
  </td> 
</tr> 
<?php }
mysql_close();
?>
</table>
</div>
</td>
</tr>
</div>

<!-- =====================================================================================================================================-->

<tr lang="en"><td align="right" class="infohead" colspan="3">
 warlock.gpl@gmail.com 

</td></tr>
</table></body>
</html>
