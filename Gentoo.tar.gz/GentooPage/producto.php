<?php
define('INCLUDE_CHECK',1);
require_once('connect.php');

    /**
     * 
     **/
    class product
    {
        
        function __construct(argument)
        {
            // code...  
        }

        function escape($value){
        if (get_magic_quotes_gpc()){$value = stripslashes($value);}
        if (!is_numeric($value)){$value = "'" . mysql_real_escape_string($value) . "'";}
        return $value;
        }
    
        function AddProduct($datos) {
        mysql_query("insert into internet_shop ()values");
        }
        
        function UpdateProduct($datos,$id){

        }
        function DeleteProduct($id){

        }
        
        function getProduct($id){

        }
        function getProducts(){

        }
        function getImagesProduct($id){

        {

        mysql_free_result($data);
        }
    }
?>
